def main():
    print("record_probe")
