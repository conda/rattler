def main():
    print("record_other")
