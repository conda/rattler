"""Fixture package for rattler wheel tests."""

__version__ = "1.0.0"


def main() -> None:
    print("moo")
