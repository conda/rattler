@echo off
REM Test fixture: a plugin whose dependency lives in the base channel.
echo {"version": 1, "virtual_packages": {"__cuda": {"version": "12.4"}}}
exit /b 0
