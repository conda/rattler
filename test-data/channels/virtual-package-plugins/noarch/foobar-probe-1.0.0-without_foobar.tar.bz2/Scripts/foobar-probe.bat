@echo off
REM Test fixture: one of the two foobar-probe builds. Which one a solve picks depends on whether __foobar was offered to the solver.
echo __foobar was NOT available at solve time (fell back to the "without_foobar" build).
exit /b 0
