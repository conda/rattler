@echo off
REM Test fixture: the odd flavour of change-me-probe.
echo __change_me was 1=odd at solve time.
exit /b 0
