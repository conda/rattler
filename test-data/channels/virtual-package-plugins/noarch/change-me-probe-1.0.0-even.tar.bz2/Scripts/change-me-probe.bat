@echo off
REM Test fixture: the even flavour of change-me-probe.
echo __change_me was 0=even at solve time.
exit /b 0
