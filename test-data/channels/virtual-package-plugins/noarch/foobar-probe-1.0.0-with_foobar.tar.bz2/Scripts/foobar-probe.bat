@echo off
REM Test fixture: one of the two foobar-probe builds. Which one a solve picks depends on whether __foobar was offered to the solver.
echo __foobar WAS available at solve time (the "with_foobar" build was installable).
exit /b 0
